import { NamedIcon } from "@/components/icons";
import type { Widget, WidgetColor } from "@/lib/control/types";
import { cn } from "@/lib/utils";

const colorClass: Record<WidgetColor, string> = {
  steel: "bg-steel/30 border-steel/50 text-fg",
  sage: "bg-sage/30 border-sage/50 text-fg",
  clay: "bg-clay/30 border-clay/50 text-fg",
  fog: "bg-fog/25 border-border text-fg",
  ink: "bg-raised border-border text-fg",
  ocean: "bg-ocean/35 border-ocean/55 text-fg",
  pine: "bg-pine/35 border-pine/55 text-fg",
  rust: "bg-rust/35 border-rust/55 text-fg",
  sand: "bg-sand/35 border-sand/55 text-fg",
  slate: "bg-slate/35 border-slate/55 text-fg",
  rose: "bg-rose/35 border-rose/55 text-fg",
};

export function WidgetShell({
  widget,
  active,
  disabled,
  children,
  onClick,
}: {
  widget: Widget;
  active?: boolean;
  disabled?: boolean;
  children?: React.ReactNode;
  onClick?: () => void;
}) {
  return (
    <button
      type="button"
      disabled={disabled}
      onClick={onClick}
      className={cn(
        "flex h-full w-full flex-col items-stretch justify-between rounded-lg border p-3 text-left transition-colors duration-150",
        colorClass[widget.color],
        active && "bg-accent text-accent-fg border-accent ring-2 ring-accent",
        disabled && "opacity-40",
      )}
    >
      <div className="flex items-center justify-between gap-2">
        <span className={cn("text-xs font-medium uppercase tracking-wide", active ? "text-accent-fg/70" : "text-muted")}>{widget.label}</span>
        <NamedIcon name={widget.icon} className={cn("size-4", active ? "text-accent-fg" : "text-muted")} />
      </div>
      <div className="mt-2 min-h-6 text-lg font-medium leading-tight">{children}</div>
    </button>
  );
}
