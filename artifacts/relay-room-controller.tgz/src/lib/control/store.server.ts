import { bundledDrivers, defaultDeviceState, defaultRoomConfig } from "./defaults";
import { readMonitorValue, runMacro } from "./engine";
import type { DeviceHealth, DeviceStateMap, DriverSpec, RoomConfig, RoomSnapshot } from "./types";
import { applyMonitors, clampVar, seedVars, type VarMap } from "./vars";

const ROW_ID = "current";

type Memory = {
  config: RoomConfig;
  drivers: Record<string, DriverSpec>;
  state: DeviceStateMap;
  vars: VarMap;
  health: DeviceHealth;
  lastError: string | null;
  runningMacro: string | null;
  activeScene: string | null;
};

const g = globalThis as typeof globalThis & {
  __relayMemory__?: Memory;
  __relaySched__?: ReturnType<typeof setInterval>;
  __relayMon__?: ReturnType<typeof setInterval>;
};
const lastScheduleRun = new Map<string, string>();
const lastMonitorRun = new Map<string, number>();

function normalize(config: RoomConfig): RoomConfig {
  const demo = defaultRoomConfig();
  return {
    ...config,
    room: {
      ...demo.room,
      ...config.room,
      network: { ...demo.room.network, ...(config.room.network ?? {}) },
      grid: { ...demo.room.grid, ...(config.room.grid ?? {}) },
    },
    variables: config.variables ?? demo.variables,
    schedules: config.schedules ?? demo.schedules,
    monitors: config.monitors ?? demo.monitors,
  };
}

function emptyMemory(): Memory {
  const config = defaultRoomConfig();
  return {
    config,
    drivers: { ...bundledDrivers },
    state: defaultDeviceState(),
    vars: seedVars(config),
    health: {},
    lastError: null,
    runningMacro: null,
    activeScene: null,
  };
}

export function memory(): Memory {
  if (!g.__relayMemory__) g.__relayMemory__ = emptyMemory();
  return g.__relayMemory__;
}

async function sqlOrNull() {
  const url = typeof process !== "undefined" ? process.env.DATABASE_URL : undefined;
  const prodWithoutDb = process.env.NODE_ENV === "production" && !url;
  if (prodWithoutDb) return null;
  try {
    const { getSql } = await import("@/lib/db");
    return await getSql();
  } catch {
    return null;
  }
}


export async function loadPersisted(): Promise<Memory> {
  const mem = memory();
  const sql = await sqlOrNull();
  if (!sql) return mem;
  try {
    const rows = await sql<{
      config_json: string;
      drivers_json: string;
      state_json: string;
    }>`select config_json, drivers_json, state_json from room_store where id = ${ROW_ID}`;
    const row = rows[0];
    if (!row) {
      await persist();
      return mem;
    }
    mem.config = normalize(JSON.parse(row.config_json) as RoomConfig);
    mem.drivers = { ...bundledDrivers, ...(JSON.parse(row.drivers_json) as Record<string, DriverSpec>) };
    mem.state = JSON.parse(row.state_json) as DeviceStateMap;
    const storedVars = mem.state.__vars as unknown as VarMap | undefined;
    delete mem.state.__vars;
    mem.vars = seedVars(mem.config, storedVars);
    mem.health = mem.health ?? {};
    applyMonitors(mem.config, mem.state, mem.vars);
  } catch {
    /* keep memory defaults */
  }
  return mem;
}

export async function persist() {
  const mem = memory();
  const sql = await sqlOrNull();
  if (!sql) return;
  try {
    const configJson = JSON.stringify(normalize(mem.config));
    const driversJson = JSON.stringify(mem.drivers);
    const stateJson = JSON.stringify({ ...mem.state, __vars: mem.vars });
    await sql`
      insert into room_store (id, config_json, drivers_json, state_json, updated_at)
      values (${ROW_ID}, ${configJson}, ${driversJson}, ${stateJson}, now())
      on conflict (id) do update set
        config_json = excluded.config_json,
        drivers_json = excluded.drivers_json,
        state_json = excluded.state_json,
        updated_at = now()
    `;
  } catch {
    /* memory remains the live source */
  }
}

export function snapshot(): RoomSnapshot {
  const mem = memory();
  mem.config = normalize(mem.config);
  mem.drivers = { ...bundledDrivers, ...mem.drivers };
  mem.vars = seedVars(mem.config, mem.vars);
  applyMonitors(mem.config, mem.state, mem.vars);
  return {
    config: mem.config,
    drivers: mem.drivers,
    state: mem.state,
    vars: mem.vars,
    health: mem.health ?? {},
    lastError: mem.lastError,
    runningMacro: mem.runningMacro,
    activeScene: mem.activeScene,
  };
}

async function runDueSchedules() {
  const mem = memory();
  const tz = mem.config.room.network?.timezone || "Europe/Brussels";
  const parts = new Intl.DateTimeFormat("en-GB", {
    timeZone: tz,
    hour: "2-digit",
    minute: "2-digit",
    hourCycle: "h23",
    weekday: "short",
  }).formatToParts(new Date());
  const hour = parts.find((p) => p.type === "hour")?.value ?? "00";
  const minute = parts.find((p) => p.type === "minute")?.value ?? "00";
  const weekday = parts.find((p) => p.type === "weekday")?.value ?? "Sun";
  const time = `${hour}:${minute}`;
  const dayMap: Record<string, number> = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 };
  const day = dayMap[weekday] ?? 0;
  const now = new Date();
  const stamp = `${tz}-${now.toISOString().slice(0, 10)}T${time}`;
  for (const job of mem.config.schedules ?? []) {
    if (!job.enabled || job.time !== time) continue;
    if (job.days.length && !job.days.includes(day)) continue;
    if (lastScheduleRun.get(job.id) === stamp) continue;
    const macro = mem.config.macros.find((m) => m.id === job.macroId);
    if (!macro) continue;
    lastScheduleRun.set(job.id, stamp);
    mem.runningMacro = macro.id;
    const result = await runMacro({ config: mem.config, drivers: mem.drivers, state: mem.state, vars: mem.vars, health: mem.health ?? (mem.health = {}), macro });
    mem.runningMacro = null;
    if (result.ok) mem.activeScene = macro.id;
    mem.lastError = result.ok ? null : result.message;
    await persist();
  }
}

async function runDueMonitors() {
  const mem = memory();
  const now = Date.now();
  let dirty = false;
  for (const rule of mem.config.monitors ?? []) {
    if (!rule.enabled || !rule.writeVar) continue;
    if (mem.health?.[rule.device] && !mem.health[rule.device]!.ok) continue;
    const wait = Math.max(400, rule.pollMs || 2000);
    const last = lastMonitorRun.get(rule.id) ?? 0;
    if (now - last < wait) continue;
    lastMonitorRun.set(rule.id, now);
    const result = await readMonitorValue({
      config: mem.config,
      drivers: mem.drivers,
      state: mem.state,
      deviceId: rule.device,
      feedbackId: rule.feedback,
    });
    if (!result.ok) continue;
    let value = result.value;
    if (rule.mapMode === "map") {
      const hit = (rule.map ?? []).find((row) => row.from === value);
      if (hit) value = hit.to;
    }
    const def = mem.config.variables.find((v) => v.id === rule.writeVar);
    const next = def ? clampVar(def, value) : value;
    if (String(mem.vars[rule.writeVar]) !== String(next)) {
      mem.vars[rule.writeVar] = next;
      dirty = true;
    }
  }
  if (dirty) await persist();
}

function startScheduler() {
  if (!g.__relaySched__) {
    g.__relaySched__ = setInterval(() => {
      runDueSchedules().catch(() => undefined);
    }, 15000);
  }
  if (!g.__relayMon__) {
    g.__relayMon__ = setInterval(() => {
      runDueMonitors().catch(() => undefined);
    }, 500);
  }
}

let boot: Promise<Memory> | null = null;
export function ensureLoaded() {
  if (!boot) {
    boot = loadPersisted().then((mem) => {
      startScheduler();
      return mem;
    });
  }
  return boot;
}
