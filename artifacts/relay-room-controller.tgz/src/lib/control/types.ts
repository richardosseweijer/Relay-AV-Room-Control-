export type TransportName = "lan" | "rs232";
export type CommandKind = "action" | "toggle" | "range" | "enum";
export type FeedbackKind = "enum" | "range" | "toggle" | "string";
export type ParseType = "regex" | "jsonpath" | "contains" | "exact";
export type FeedbackMode = "poll" | "push";
export type ChecksumKind = "none" | "sum8" | "xor8" | "pjlink";
export type DriverPairing = {
  kind: "none" | "websocket-handshake" | "http-probe" | "http-handshake";
  ports?: number[];
  path?: string;
  query?: {
    nameParam?: string;
    tokenParam?: string;
    nameFrom?: "auth.name" | "room";
  };
  tlsPorts?: number[];
  waitContains?: string;
  commandAck?: "none" | "message";
  tokenJsonPath?: string;
  userPrompt?: string;
  discoverPath?: string;
};
export type AuthType = "none" | "password" | "token" | "header";
export type LanProtocol = "tcp" | "udp" | "http" | "websocket";

export type MatchRule = {
  type: ParseType;
  value?: string;
  pattern?: string;
  path?: string;
  map?: Record<string, string>;
};

export type DriverSpec = {
  specVersion: string;
  device: {
    manufacturer: string;
    model: string;
    type: string;
    manualUrl?: string;
    notes?: string;
  };
  transports: {
    lan?: {
      protocol: LanProtocol;
      port: number;
      encoding?: string;
      lineEnding?: string;
      timeoutMs?: number;
      http?: {
        method?: string;
        path?: string;
        headers?: Record<string, string>;
        contentType?: string;
      };
    };
    rs232?: {
      baud: number;
      dataBits: number;
      parity: string;
      stopBits: number;
      encoding?: string;
      lineEnding?: string;
      timeoutMs?: number;
    };
  };
  auth?: {
    type: AuthType;
    instanceFields?: string[];
    pairing?: DriverPairing;
  };
  session?: {
    connect?: string[];
    keepalive?: { payload?: string | null; intervalMs?: number };
    disconnect?: string[];
  };
  pacing?: { minIntervalMs?: number; powerOnDelayMs?: number };
  probe?: { transport: TransportName; payload: string; success: MatchRule };
  helpers?: { checksum?: ChecksumKind };
  commands: DriverCommand[];
  feedback: DriverFeedback[];
};

export type DriverCommand = {
  id: string;
  label: string;
  kind: CommandKind;
  transport: TransportName;
  payload: string;
  httpPath?: string;
  httpMethod?: string;
  min?: number;
  max?: number;
  step?: number;
  unit?: string;
  values?: string[];
  requires?: string[];
  ack?: { success?: MatchRule; nak?: MatchRule };
};

export type DriverFeedback = {
  id: string;
  label: string;
  kind: FeedbackKind;
  transport: TransportName;
  mode: FeedbackMode;
  query?: string;
  pollMs?: number;
  values?: string[];
  min?: number;
  max?: number;
  parse: MatchRule;
};

export type PanelAccess = "open" | "pin";
export type WidgetType = "button" | "toggle" | "slider" | "label" | "status";
export type BindKind = "command" | "feedback" | "macro" | "gotoPage" | "range" | "variable";
export type FailKind = "macro" | "gotoPage" | "none";
export type WidgetColor = "steel" | "sage" | "clay" | "fog" | "ink" | "ocean" | "pine" | "rust" | "sand" | "slate" | "rose";

export type EnableWhen = {
  device?: string;
  feedback?: string;
  variable?: string | null;
  equals: string;
};

export type WidgetBind = {
  kind: BindKind;
  id?: string;
  device?: string;
  command?: string;
  feedback?: string;
  value?: string | number;
  gotoPage?: string | null;
  variable?: string | null;
};

export type Widget = {
  id: string;
  type: WidgetType;
  x: number;
  y: number;
  w: number;
  h: number;
  label: string;
  color: WidgetColor;
  icon?: string;
  confirm?: boolean;
  enableWhen?: EnableWhen | null;
  min?: number | string;
  max?: number | string;
  bind: WidgetBind;
};

export type MacroStep = {
  device?: string;
  command?: string;
  value?: string | number;
  setVar?: string | null;
  skipIf?: { feedback: string; equals: string };
  delayMsAfter?: number;
};

export type RoomVariable = {
  id: string;
  label: string;
  kind: "number" | "enum";
  default: string | number;
  min?: number;
  max?: number;
  step?: number;
  values?: string[];
};

export type Schedule = {
  id: string;
  label: string;
  enabled: boolean;
  time: string;
  days: number[];
  macroId: string;
};

export type MonitorRule = {
  id: string;
  label: string;
  enabled: boolean;
  device: string;
  feedback: string;
  pollMs: number;
  writeVar: string | null;
  mapMode: "raw" | "map";
  map: { from: string; to: string }[];
};

export type Page = {
  id: string;
  label: string;
  grid: { cols: number; rows: number };
  widgets: Widget[];
};

export type DeviceInstance = {
  id: string;
  name: string;
  driver: string;
  transport: TransportName;
  host: string;
  port?: number;
  auth: Record<string, string>;
  enabledFeatures: string[];
  simulate: boolean;
};

export type Macro = {
  id: string;
  label: string;
  retries: number;
  onFail: { kind: FailKind; id?: string };
  steps: MacroStep[];
};

export type RoomConfig = {
  configVersion: string;
  exportedAt: string | null;
  sourceRoomId: string | null;
  room: {
    id: string;
    name: string;
    panelAccess: PanelAccess;
    panelPin: string | null;
    configPin: string;
    theme: "dark" | "light";
    idleDimSeconds: number;
    grid: { cols: number; rows: number };
    network: {
      mode: "dhcp" | "static";
      address: string;
      prefix: number;
      gateway: string;
      dns: string;
      ntp: string;
      timezone: string;
      hostname: string;
    };
  };
  devices: DeviceInstance[];
  pages: Page[];
  macros: Macro[];
  variables: RoomVariable[];
  schedules: Schedule[];
  monitors: MonitorRule[];
};

export type DeviceStateMap = Record<string, Record<string, string | number | boolean>>;

export type DeviceHealth = Record<string, { ok: boolean; message: string }>;

export type RoomSnapshot = {
  config: RoomConfig;
  drivers: Record<string, DriverSpec>;
  state: DeviceStateMap;
  vars: Record<string, string | number>;
  health: DeviceHealth;
  lastError: string | null;
  runningMacro: string | null;
  activeScene: string | null;
};

export type CommandResult = {
  ok: boolean;
  message: string;
  pairedToken?: string;
  pairedPort?: number;
};
